<?php
session_start();
include('database.php');
if (isset($_SESSION['email'])) {
	?>
		<!DOCTYPE html>
		<html>
		<head>
			<title>Alumni System</title>
			<meta charset="utf-8">
			<link rel="stylesheet" type="text/css" href="css/style2.css">
			<link rel="stylesheet" type="text/css" href="css/style.css">
		</head>
		<body>
			<div class="main">
				<div class="top">
					<h1>Alumni System</h1>
				</div>
				<?php
					include('menu.php');
				?>
				<div class="mid">
					<a href="add.php"><button class="button">Create new survey</button></a>
				</div>
			</div>
		</body>
		</html>
	<?php
}else{
	header('location: login.php');
}
?>