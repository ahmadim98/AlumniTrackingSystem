<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ChatController
 *
 * @author aim
 */

include 'database.php';

class ChatController {
    public $GraduateID;
    public $AlumniName;
    public $AdminID;
    
    public function __construct($chatID,$adminName) {
        $this->GraduateID = $GLOBALS['bdd']->query('SELECT GraduateID FROM feedback WHERE ID = '.$chatID.'')->fetch()['GraduateID'];
        //$this->AlumniName = $GLOBALS['bdd']->query('SELECT * FROM `alumni` WHERE `alumni_id` = '.$this->GraduateID.'')->fetch()['name'];
        
        $this->AdminID = $GLOBALS['bdd']->query('SELECT ID FROM admin WHERE Username = "'.$adminName.'"')->fetch()['ID'];
    }
    
    public function sendFeedback(array $request,$id){
        $GLOBALS['bdd']->exec('INSERT INTO `feedbackchat` (`ID`, `feedbackID`, `message`, `sender`, `receiver`) VALUES (NULL, '.$_GET['id'].', "'.htmlspecialchars($_POST['msg']).'", "'.$AdminID.'", "'.$GraduateID.'")');
	header('location: chat.php?id=' . $id);
    }
    
    public function readFeedback(){
        $feedbackchat = $GLOBALS['bdd']->query('SELECT * FROM feedbackchat')->fetchAll();
                                                                
        if(!empty($feedbackchat)){
            foreach($feedbackchat as $chat){
            $sender = $chat['sender'];
            //over here we want to check if the sender's id start with 4 means that
            //the alumni is sending message
            if(!empty($sender) && $sender[0] == 4){
                echo '
                    <div class="bHim">
                            <p>' . $chat['message'] . '</p>
                    </div>
                ';
            }else{
                echo '
                    <div class="aMe">
                            <p class="text-right">' . $chat['message'] . '</p>
                    </div>
                ';
            }

        }
        }else{
           echo '
                    <br><br><br><br><br><br>
                            <h1 style="text-align:center;">No message</h1>
                    <br><br><br>
                    '; 
        }
        
    }
}
