<?php
/**
 * Description of AdminController
 *
 * @author aim
 */
include 'database.php';


class AdminController {
    
    public $ID;
    public $Username;
    
    function __construct($Username,$Password) {
        if (mb_strlen($Password) > 5) {
            $Password = sha1($Password);
            //$GLOBALS['bdd'];
            $login = $GLOBALS['bdd']->prepare('SELECT * FROM admin WHERE Username = ?');
            $login->execute(array($Username));
            
            if ($login->rowCount() == 1) {
                if ($Password == $login->fetch()['Password']) {
                    $_SESSION['username'] = $Username;
                    //here write some other things
                    $this->Username = $Username;
                    
                    header('location: ./statistic.php');
                } else {
                    $error = 'The username/password is/are wrong';
                }
            } else {
                $error = 'There is no account with this username';
            }
            
        } else {
            $error = 'There is a problem in the password';
        }
        
    }
    //put your code here
    
    function test(){
        echo "test";
    }
    
    function newStatistics(array $request){
        $con = new mysqli("localhost","root","","alumnisystem");
        $con->query("set names utf8");
        
        $series = "series: [";
        $labels = "labels: [";
        if(isset($request['submit']))
        {
            $nAlumni = "SELECT alumni_id FROM alumni;";
            $query = mysqli_query($con, $nAlumni);
            $row_com = mysqli_fetch_array($query);
            $nAll = mysqli_num_rows($query);

            $major = "";
            $job= "";
            $place = "";
            if(isset($request['2']))
            {
              $major = "major =" . "'" . $request['major'] . "'" . " AND " ;
            }
            if(isset($request['3']))
            {
                if(isset($request['4']))
                {
                  $job = "jobtitle = " . "'" . $request['jobtitle'] . "'" . " AND " ;
                }
                else
                {
                      $job = "jobtitle = " . "'" . $request['jobtitle'] . "'"  ; 
                }
            }
            if(isset($request['4']))
            {
                $place = "place = "  . "'". $request['place'] . "'" ;
            }
            if (isset($request['1']))
            {
              $nSub = 0;
              $data = "data: [";
              $categories = "categories: [";

              for($i=$request['year1'] ; $i<= $request['year2']; $i++)
              {
                if(isset($request['3']) || isset($request['4']))
                {
                  $nAlumni1 = "SELECT DISTINCT alumni_id
                  FROM alumni
                  WHERE " .  $major . "alumni_id IN
                  (SELECT alumni_id FROM experience WHERE startD = " . $i . " AND " .  $job . $place . ");";
                }
                else
                {
                  $nAlumni1 = "SELECT DISTINCT alumni_id
                  FROM alumni
                  WHERE " .  $major . "alumni_id IN
                  (SELECT alumni_id FROM experience WHERE startD = " . $i . $job . $place . ");";
                }
                $query1 = mysqli_query($con, $nAlumni1);
                $row_com1 = mysqli_fetch_array($query1);
                $nYear = mysqli_num_rows($query1);
                echo "Number of employed in " .  $i . "=" . $nYear . "<br>" ;
                $nSub += $nYear;
                $data.= $nYear . ",";
                $categories.= '"' . $i . '" ,';
                $series.= $nYear . ",";
                $labels.= '"' . $i . '" ,';
              }
            $data.= "]";
            $categories.= "]";
            $series.= "]";
            $labels.= "]";
            echo "the number of alumni = " . $nAll . "<br>";

            echo "percentage of employees = "  . ($nSub / $nAll) * 100 . "%";
            }
            //comment this block of code
            else
            {
              if(isset($request['3']) || isset($request['4']))
              {
                $nAlumni1 = "SELECT DISTINCT alumni_id
                FROM alumni
                WHERE " .  $major . "alumni_id IN
                (SELECT alumni_id FROM experience WHERE " .  $job . $place . ");";
              }
              else
              {
                $nAlumni1 = "SELECT DISTINCT alumni_id
                FROM alumni
                WHERE " .  $major . "alumni_id IN
                (SELECT alumni_id FROM experience  " .  $job . $place . ");";
              }


              $query = mysqli_query($con, $nAlumni1);
              $row_com = mysqli_fetch_array($query);
              $nSub = mysqli_num_rows($query);
              echo "the number of alumni = " . $nAll . "<br>";
              echo "percentage of employees = "  . ($nSub / $nAll) * 100 . "%";
              $series.= $nSub . "," . ($nAll-$nSub) . "]";
              $labels.= '"Employees" , "Not employed"]'; 
          }
          // end comment

        }       

        if(isset($request['submit']) && isset($request['1']))
        {          
          echo '<script type="text/babel">
          class ApexChart extends React.Component {
          constructor(props) {
          super(props);

          this.state = {

          series: [{
              name: "employees",
            ' . $data . ' 
          }],
          options: {
            chart: {
              height: 350,
              type: "line",
              zoom: {
                enabled: false
              }
          },
          dataLabels: {
            enabled: false
          },
          stroke: {
            curve: "straight"
          },
          title: {
            text: "",
            align: "left"
          },
          grid: {
            row: {
              colors: ["#f3f3f3", "transparent"], // takes an array which will be repeated on columns
              opacity: 0.5
            },
          },
          xaxis: {
            ' . $categories . ',
          }
        },


          };
        }



          render() {
            return (
              <div>
                <div id="chart">
                  <ReactApexChart options={this.state.options} series={this.state.series} type="line" height={350} />
                </div>
                <div id="html-dist"></div>
              </div>
            );
          }
        }

        const domContainer = document.querySelector("#app");
        ReactDOM.render(React.createElement(ApexChart), domContainer);
      </script>';
        }
        if(isset($request['submit'])){
        echo '  <script type="text/babel">
        class ApexChart extends React.Component {
          constructor(props) {
            super(props);

            this.state = {

            ' . $series . ',
              options: {
                chart: {
                  width: 380,
                  type: "pie",
                },
                ' . $labels . ',
                responsive: [{
                  breakpoint: 480,
                  options: {
                    chart: {
                      width: 200
                    },
                    legend: {
                      position: "bottom"
                    }
                  }
                }]
              },


            };
          }



          render() {
            return (
              <div>
                <div id="chart">
                  <ReactApexChart options={this.state.options} series={this.state.series} type="pie" width={380} />
                </div>
                <div id="html-dist"></div>
              </div>
            );
          }
        }

        const domContainer = document.querySelector("#app2");
        ReactDOM.render(React.createElement(ApexChart), domContainer);
      </script>';
            echo "<br>" . "<button onclick='window.print();'target='_blank'>print</button>";
    }
    }
    
}

class Statistics{
    
}

class StatisticsData{
    
}

/*class Admin{
    public $ID;
    public $Name;
    
}*/
