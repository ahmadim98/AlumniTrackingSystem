<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SurveyController
 *
 * @author aim
 */

include 'database.php';

class SurveyController {
    //put your code here
    
    public function getSurveys(){
        $con = new mysqli("localhost","root","","alumnisystem");
        $con->query("set names utf8");
        $show = 1;
        $all = $GLOBALS['bdd']->query('SELECT * FROM survey ORDER BY ID DESC');
        while ($get = $all->fetch()) {
            $nAnswer = "SELECT * FROM answers WHERE survey =" . $get['ID'] . ";";
            $query = mysqli_query($con, $nAnswer);
            $row_com = mysqli_fetch_array($query);
            $nAn = mysqli_num_rows($query);

            echo '
                            <li class="list-group-item">
            ' . $get['Surveyname'] . ' 
            <button style="background-color: #0084bd;" type="button" class="btn btn-primary btn-sm" data-toggle="collapse" href="#multiCollapseExample'.$show.'" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Show</button><br>
            <div class="collapse multi-collapse" id="multiCollapseExample'.$show.'">
             The number of alumni who filled out the survey=' . $nAn ;
            $Qu = $GLOBALS['bdd']->query('SELECT * FROM survey_questions WHERE SurveyID =' .$get['ID']);
            $i= 1;
            while ($get0 = $Qu->fetch()){
                echo "<br>" ."Question" . $i . ":" . $get0['Question'] . ":-" ;
                $i++;
                $Op = $GLOBALS['bdd']->query('SELECT * FROM survey_options WHERE QuestionID =' .$get0['ID']);
                $j= 1;
                while ($get1 = $Op->fetch()){
            $nSAnswer = "SELECT * FROM answers WHERE survey =" . $get['ID'] . " AND answers= ' " . $get1['Optionname'] . "';";
            $query1 = mysqli_query($con, $nSAnswer);
            $row_com1 = mysqli_fetch_array($query1);
            $nSAn = mysqli_num_rows($query1);
                    $n = ($nSAn/$nAn) * 100 ;
                    echo "<br>" . " -option" . $j . ":" .  $get1['Optionname'] . "=" . $n . "%" ;
                }
            } 
             echo
             '
             </div>
             </li>';
             $show = $show +1;
        }
    }
    
    public function createSurvey(array $request,$username){
        $AdminID = $GLOBALS['bdd']->query('SELECT ID FROM admin WHERE Username = "'.$username.'"')->fetch()['ID'];
        $Surveyname = htmlspecialchars($request['Surveyname']);
        $GLOBALS['bdd']->exec('INSERT INTO `survey`(`ID`, `AdminID`, `Surveyname`) VALUES (NULL,'.$AdminID.',"'.$Surveyname.'")');
        $SurveyID = $GLOBALS['bdd']->query('SELECT ID FROM survey WHERE Surveyname = "'.$Surveyname.'"')->fetch()['ID'];

        foreach ($request['form'] as $Question) {
                if (!empty($Question[0])) {
                        $GLOBALS['bdd']->exec('INSERT INTO `survey_questions`(`ID`, `SurveyID`, `Question`) VALUES (NULL,'.$SurveyID.',"'.$Question[0].'")');

                        $QuestionID = $GLOBALS['bdd']->query('SELECT ID FROM survey_questions WHERE Question = "'.$Question[0].'" AND SurveyID = '.$SurveyID.'')->fetch()['ID'];

                        foreach ($Q[1] as $Option) {//here as 
                            $GLOBALS['bdd']->exec('INSERT INTO `survey_options`(`QuestionID`, `SurveyID`, `Optionname`) VALUES ('.$QuestionID.','.$SurveyID.',"'.$Option.'")');
                        }
                }

        }
        header('location: surveys.php?id=' . $id);
	
    }
}
