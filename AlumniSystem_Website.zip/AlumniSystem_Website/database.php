<?php

//$host = 'localhost';
//$db = 'alumnisystem';
//$login = 'root';
//$pass = '';

$host = "mysql:host=127.0.0.1;dbname=alumnisystem";
$login = "root";
$pass = "";

$bdd = new PDO($host, $login, $pass);

?>