-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2020 at 08:45 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alumnisystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `Username`, `Password`) VALUES
(0, 'test', '7c4a8d09ca3762af61e59520943dc26494f8941b');

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `alumni_id` int(11) NOT NULL,
  `major` varchar(255) NOT NULl,
  `twiterAccont`varchar(255) NOT NULl,
  `phone`  int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`alumni_id`, `major`, twiterAccont , phone ) VALUES
(1, 'SWE', 'manager', 055),
(2,  'SWE' , 'ff' , 066 ),
(3,  'SWE' , 'qq' , 044),
(43,  'CSC' , 'ww' , 077),
(5,  'CSC' , 'ee' , 033),
(6,  'CE' , 'rr' , 088);

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `survey` int(11) NOT NULL,
  `answers` text COLLATE utf8_unicode_ci NOT NULL,
  `date_add` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `survey`, `answers`, `date_add`) VALUES
(1, 1, 'steve\r\nno', '2020-02-12'),
(2, 1, 'lkdf\r\nsdsd', '2020-02-12'),
(3, 2, 'dssdsd', '2020-02-04'),
(4, 3, 'ds', '2020-02-03'),
(5, 2, 'dssd', '2020-02-02'),
(6, 1, '056\r\nds', '2020-02-28'),
(8, 1, '043sdd\r\ndssds', '2020-02-28'),
(9, 1, 'ez\r\nze', '2020-02-28');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `a` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `b` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `msg` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `a`, `b`, `msg`) VALUES
(1, 'justtest@gmail.com', 'test@test.com', 'testing'),
(2, 'test@test.com', 'justtest@gmail.com', 'testing'),
(3, 'test@test.com', 'justtest@gmail.com', 'testing'),
(4, 'justtest@gmail.com', 'test@test.com', 'testing'),
(5, 'test@test.com', 'justtest@gmail.com', 'testing'),
(6, 'test@test.com', 'justtest@gmail.com', 'testing'),
(7, 'test@test.com', 'justtest@gmail.com', 'testing'),
(8, 'justtest@gmail.com', 'test@test.com', 'testing'),
(9, 'justtest@gmail.com', 'test@test.com', 'testing'),
(10, 'justtest@gmail.com', 'test@test.com', 'testing'),
(11, 'justtest@gmail.com', 'test@test.com', 'testing'),
(12, 'test@test.com', 'justtest@gmail.com', 'testing'),
(13, 'justtest@gmail.com', 'test@test.com', 'testing'),
(14, 'test@test.com', 'justtest@gmail.com', 'testing'),
(15, 'test@test.com', 'justtest@gmail.com', 'test18-8-1441');

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `job_id` int(11) NOT NULL,
  `jobtitle` varchar(255) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `place` varchar(255) NOT NULL,
  `startD` year(4) NOT NULL,
  `endD` year(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`job_id`, `jobtitle`, `alumni_id`, `place`, `startD`, `endD`) VALUES
(1, 'dev', 1, 'STC', 2014, 2015),
(3, 'des', 2, 'mobily', 2012, 2015),
(5, 'anal', 3, 'TC', 2016, 2017),
(7, 'anal', 4, 'gov', 2013, 2015),
(8, 'dev', 5, 'STC', 2015, 2016),
(9, 'dev', 6, 'STC', 2014, 2015);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `ID` int(11) NOT NULL,
  `GraduateID` int(11) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`ID`, `GraduateID`, `title`) VALUES
(1, 43, 'test feedback');

-- --------------------------------------------------------

--
-- Table structure for table `feedbackchat`
--

CREATE TABLE `feedbackchat` (
  `ID` int(11) NOT NULL,
  `feedbackID` int(11) NOT NULL,
  `message` varchar(500) NOT NULL,
  `sender` varchar(1000) NOT NULL,
  `receiver` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbackchat`
--

INSERT INTO `feedbackchat` (`ID`, `feedbackID`, `message`, `sender`, `receiver`) VALUES
(1, 1, 'this is test message', '43', '0'),
(2, 1, 'fdsafdas', '0', '43'),
(3, 1, 'this is other test', '0', '43'),
(4, 1, 'ffdsafdsa', '0', '43'),
(5, 1, 'fdsa', '0', '43'),
(6, 1, 'fdsa', '0', '43'),
(7, 1, 'dfsafdsa', '0', '43'),
(8, 1, 'fdsafdas', '0', '43');

-- --------------------------------------------------------

--
-- Table structure for table `survey`
--

CREATE TABLE `survey` (
  `ID` int(11) NOT NULL,
  `AdminID` int(11) NOT NULL,
  `Surveyname` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `survey`
--

INSERT INTO `survey` (`ID`, `AdminID`, `Surveyname`) VALUES
(1, 0, 'Big brother'),
(2, 0, 'hi'),
(3, 0, 'test'),
(4, 0, 'test1'),
(5, 0, 'add1'),
(6, 0, 'first test'),
(7, 0, 'this is test survey'),
(8, 0, 'this is test survey'),
(9, 0, 'this is test survey'),
(10, 0, 'this is test survey');

-- --------------------------------------------------------

--
-- Table structure for table `survey_options`
--

CREATE TABLE `survey_options` (
  `QuestionID` int(11) NOT NULL,
  `SurveyID` int(11) NOT NULL,
  `Optionname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_options`
--

INSERT INTO `survey_options` (`QuestionID`, `SurveyID`, `Optionname`) VALUES
(1, 1, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `survey_questions`
--

CREATE TABLE `survey_questions` (
  `ID` int(11) NOT NULL,
  `SurveyID` int(11) NOT NULL,
  `Question` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_questions`
--

INSERT INTO `survey_questions` (`ID`, `SurveyID`, `Question`) VALUES
(1, 1, 'test'),
(2, 7, 'fdasfdsa'),
(3, 1, 'test2'),
(4, 1, 'test3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`alumni_id`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`job_id`),
  ADD KEY `alumni_id` (`alumni_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `feedbackchat`
--
ALTER TABLE `feedbackchat`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `survey`
--
ALTER TABLE `survey`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedbackchat`
--
ALTER TABLE `feedbackchat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `survey`
--
ALTER TABLE `survey`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `survey_questions`
--
ALTER TABLE `survey_questions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
