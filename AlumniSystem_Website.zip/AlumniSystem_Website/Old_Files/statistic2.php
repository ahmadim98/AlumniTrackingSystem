<?php

    $con = new mysqli("localhost","root","","alumnisystem");
    $con->query("set names utf8");



?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title></title>

    <link href="../../assets/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <style>
      
        #chart {
      max-width: 650px;
      margin: 35px auto;

      
    }
      
    </style>

    <script>
      window.Promise ||
        document.write(
          '<script src="https://cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.min.js"><\/script>'
        )
      window.Promise ||
        document.write(
          '<script src="https://cdn.jsdelivr.net/npm/eligrey-classlist-js-polyfill@1.2.20171210/classList.min.js"><\/script>'
        )
      window.Promise ||
        document.write(
          '<script src="https://cdn.jsdelivr.net/npm/findindex_polyfill_mdn"><\/script>'
        )
    </script>

    
    <script src="https://cdn.jsdelivr.net/npm/react@16.12/umd/react.production.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/react-dom@16.12/umd/react-dom.production.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/prop-types@15.7.2/prop-types.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/babel-core/5.8.34/browser.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://cdn.jsdelivr.net/npm/react-apexcharts@1.3.6/dist/react-apexcharts.iife.min.js"></script>
    

    <script>
      // Replace Math.random() with a pseudo-random number generator to get reproducible results in e2e tests
      // Based on https://gist.github.com/blixt/f17b47c62508be59987b
      var _seed = 42
      Math.random = function() {
        _seed = (_seed * 16807) % 2147483647
        return (_seed - 1) / 2147483646
      }
    </script>

    
  </head>

  <body>
      
      <!-- navbar * -->
        <?php include 'include/header.php'; ?>
      <!-- navbar / -->
      
      <div class="container">
      <h1>The percentage of employees</h1>
        <h4>With these customizations</h2>
        <hr>
        <div class="row">
          <div class="col-sm mt-2">
            <form method="POST">
                <input type="checkbox" name="1">from :&nbsp;&nbsp; 
                <?php echo "<select name='year1'>";
                for ($i =2008 ;$i <= 2030;$i++){
                    echo "<option value=" . $i . ">" . $i . "</option>";
                }
                echo "</select>";?> to <?php echo "<select name='year2'>";
                for ($i =2008 ;$i <= 2030;$i++){
                    echo "<option value=" . $i . ">" . $i . "</option>";
                }
                echo "</select>";?>   <br>
                
                <input class="mt-3" type="checkbox" name="2">major :&nbsp; <select name="major">
                                                        <option value="SWE">software engineer</option>
                                                        <option value="CSC">Computer Science</option>
                                                        <option value="CE">computer engineer</option>
                                                        <option value="IS">Information Systems</option>
                                                        </select> <br>
                <input class="mt-3" type="checkbox" name="3">Job Name :&nbsp; <select name="jobtitle">
                                                        <option value="dev">Developer</option>
                                                        <option value="des">Designer</option>
                                                        <option value="anal">Analyst</option>
                                                        <option value="other">Others</option>
                                                        </select> <br>
                <input class="mt-3" type="checkbox" name="4">In : &nbsp; <select name="place">
                                                        <option value="STC">saudi telecom company</option>
                                                        <option value="mobily">Mobily</option>
                                                        <option value="TC">telecom company</option>
                                                        <option value="IC">Information center</option>
                                                        <option value="gov">Governmental place</option>
                                                        <option value="other">Others</option>
                                                        </select> <br>
                <button name="submit" type="submit" class="btn btn-primary btn-sm mt-3" style="background-color: #0084bd;">submit</button>
            </form>
          </div> 
        </div>
        <div class="row mt-5">
                <div class="col-lg-12">
                <nav>
                  <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Line graph</a>
                    <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Pie char</a>
                    <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Statistes</a>
                  </div>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                  <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"><div id="app"></div></div>
                  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"><div id="app2"></div></div>
                  <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"><div class="mt-3" id="html">
                  <?php
              $series = "series: [";
              $labels = "labels: [";
              if(isset($_POST['submit']))
              {
                $nAlumni = "SELECT alumni_id FROM alumni;";
                $query = mysqli_query($con, $nAlumni);
                $row_com = mysqli_fetch_array($query);
                $nAll = mysqli_num_rows($query);
      
                $major = "";
                $job= "";
                $place = "";
                if(isset($_POST['2']))
                {
                  $major = "major =" . "'" . $_POST['major'] . "'" . " AND " ;
                }
                if(isset($_POST['3']))
                {
                    if(isset($_POST['4']))
                    {
                      $job = "jobtitle = " . "'" . $_POST['jobtitle'] . "'" . " AND " ;
                    }
                    else
                    {
                          $job = "jobtitle = " . "'" . $_POST['jobtitle'] . "'"  ; 
                    }
                }
                if(isset($_POST['4']))
                {
                    $place = "place = "  . "'". $_POST['place'] . "'" ;
                }
                if (isset($_POST['1']))
                {
                  $nSub = 0;
                  $data = "data: [";
                  $categories = "categories: [";
          
                  for($i=$_POST['year1'] ; $i<= $_POST['year2']; $i++)
                  {
                    if(isset($_POST['3']) || isset($_POST['4']))
                    {
                      $nAlumni1 = "SELECT DISTINCT alumni_id
                      FROM alumni
                      WHERE " .  $major . "alumni_id IN
                      (SELECT alumni_id FROM experience WHERE startD = " . $i . " AND " .  $job . $place . ");";
                    }
                    else
                    {
                      $nAlumni1 = "SELECT DISTINCT alumni_id
                      FROM alumni
                      WHERE " .  $major . "alumni_id IN
                      (SELECT alumni_id FROM experience WHERE startD = " . $i . $job . $place . ");";
                    }
                    $query1 = mysqli_query($con, $nAlumni1);
                    $row_com1 = mysqli_fetch_array($query1);
                    $nYear = mysqli_num_rows($query1);
                    echo "Number of employed in " .  $i . "=" . $nYear . "<br>" ;
                    $nSub += $nYear;
                    $data.= $nYear . ",";
                    $categories.= '"' . $i . '" ,';
                    $series.= $nYear . ",";
                    $labels.= '"' . $i . '" ,';
                  }
                $data.= "]";
                $categories.= "]";
                $series.= "]";
                $labels.= "]";
                echo "the number of alumni = " . $nAll . "<br>";
          
                echo "percentage of employees = "  . ($nSub / $nAll) * 100 . "%";
                }
                //comment this block of code
                else
                {
                  if(isset($_POST['3']) || isset($_POST['4']))
                  {
                    $nAlumni1 = "SELECT DISTINCT alumni_id
                    FROM alumni
                    WHERE " .  $major . "alumni_id IN
                    (SELECT alumni_id FROM experience WHERE " .  $job . $place . ");";
                  }
                  else
                  {
                    $nAlumni1 = "SELECT DISTINCT alumni_id
                    FROM alumni
                    WHERE " .  $major . "alumni_id IN
                    (SELECT alumni_id FROM experience  " .  $job . $place . ");";
                  }
        
          
                  $query = mysqli_query($con, $nAlumni1);
                  $row_com = mysqli_fetch_array($query);
                  $nSub = mysqli_num_rows($query);
                  echo "the number of alumni = " . $nAll . "<br>";
                  echo "percentage of employees = "  . ($nSub / $nAll) * 100 . "%";
                  $series.= $nSub . "," . ($nAll-$nSub) . "]";
                  $labels.= '"Employees" , "Not employed"]'; 
              }
              // end comment
      
            }       
      
            if(isset($_POST['submit']) && isset($_POST['1']))
            {          
              echo '<script type="text/babel">
              class ApexChart extends React.Component {
              constructor(props) {
              super(props);

              this.state = {
          
              series: [{
                  name: "employees",
                ' . $data . ' 
              }],
              options: {
                chart: {
                  height: 350,
                  type: "line",
                  zoom: {
                    enabled: false
                  }
              },
              dataLabels: {
                enabled: false
              },
              stroke: {
                curve: "straight"
              },
              title: {
                text: "",
                align: "left"
              },
              grid: {
                row: {
                  colors: ["#f3f3f3", "transparent"], // takes an array which will be repeated on columns
                  opacity: 0.5
                },
              },
              xaxis: {
                ' . $categories . ',
              }
            },
          
          
          };
        }

            

              render() {
                return (
                  <div>
                    <div id="chart">
                      <ReactApexChart options={this.state.options} series={this.state.series} type="line" height={350} />
                    </div>
                    <div id="html-dist"></div>
                  </div>
                );
              }
            }

            const domContainer = document.querySelector("#app");
            ReactDOM.render(React.createElement(ApexChart), domContainer);
          </script>';
            }
            if(isset($_POST['submit'])){
            echo '  <script type="text/babel">
            class ApexChart extends React.Component {
              constructor(props) {
                super(props);

                this.state = {
                
                ' . $series . ',
                  options: {
                    chart: {
                      width: 380,
                      type: "pie",
                    },
                    ' . $labels . ',
                    responsive: [{
                      breakpoint: 480,
                      options: {
                        chart: {
                          width: 200
                        },
                        legend: {
                          position: "bottom"
                        }
                      }
                    }]
                  },
                
                
                };
              }

            

              render() {
                return (
                  <div>
                    <div id="chart">
                      <ReactApexChart options={this.state.options} series={this.state.series} type="pie" width={380} />
                    </div>
                    <div id="html-dist"></div>
                  </div>
                );
              }
            }

            const domContainer = document.querySelector("#app2");
            ReactDOM.render(React.createElement(ApexChart), domContainer);
          </script>';
                echo "<br>" . "<button onclick='window.print();'target='_blank'>print</button>";
        }
       ?></div></div>
                </div>
                </div>
                
        </div>
        
      
    </div>
      
    
    
    
      
    </div>



<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>