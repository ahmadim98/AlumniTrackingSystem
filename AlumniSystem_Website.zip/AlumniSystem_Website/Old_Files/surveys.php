<?php
session_start();
include('database.php');

if (isset($_SESSION['username'])) {
    if (isset($_GET['id'])) {
        
        $Surveyname = $bdd->query('SELECT * FROM survey WHERE ID = '.(int) $_GET['id'].'')->fetch()['Surveyname'];
        $Questions = $bdd->query('SELECT * FROM survey_questions WHERE SurveyID = '.(int) $_GET['id'].'')->fetchAll();
        //
        //echo $Questions[2];
        foreach($Questions as $q){
            echo 'questions '.$q['Question'];
        }
        //here if any updates happens
        if (isset($_POST['submit'], $_POST['form'], $_POST['Surveyname'])) {
            $Title = htmlspecialchars($_POST['Surveyname']);
            $Question = '';
            foreach ($_POST['form'] as $Q) {
                if (!empty($Q[0])) {
                    $Question .= $Q[0] . "|/\|";
                    foreach ($Q[1] as $form) {
                        $Question .= $form . "|/\|";
                    }
                    $Question .= "\n";
                }
            }
            $Update = $bdd->prepare('UPDATE survey SET title=:title,Q=:Q WHERE id=:id');
            $Update->execute(array(
                'title' => $Title,
                'Q' => $Question,
                'id' => $id
            ));
            header('location: surveys.php');
        }
        
        ?>
        <!DOCTYPE html>
        <html>
            <head>
                <title>Surveys list</title>
                <meta charset="utf-8">
                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
                <style type="text/css">
                </style> 
            </head>
            <body>
                <?php include 'include/header.php'; ?>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 mt-3 text-center">
                            <h4>Update the survey<br>(empty to delete)</h4>
                            <hr>
                            <form method="post" action="">
                                <?php
                                echo '
                                <div class="form-group">
                                    <input type="text" name="Surveyname" class="form-control" placeholder="Write a title of this survey..." class="text" value="' . $Surveyname . '">
                                </div>';
                                
                                echo '<div class="Inputs" id="Inputs">';
                                
                                $i = 0;
                                
                                foreach ($Questions as $question) {
                                    echo '						
                                        <div class="form-group">
                                                <input type="text" class="form-control" name="form[' . $i . '][0]" id="0" placeholder="Write a question..." required class="text" value="' . $question['Question'] . '">
                                        </div>';
                                        $Options = $bdd->query('SELECT * FROM survey_options WHERE SurveyID = '.(int) $_GET['id'].' AND QuestionID = '.$question['ID'].'')->fetch()['Optionname'];
                                        foreach($Options as $option){
                                            echo'<div class="text-center">
                                                <label>Write the answers:</label>

                                                        <div class="form-group row">
                                                                <label for="staticEmail" class="col-sm-2 col-form-label">	<input type="radio" readonly>	</label>
                                                                        <div class="col-sm-10">
                                                                                <input class="form-control" type="text" name="form[' . $i . '][1][0]" required placeholder="Answer 1..." value="' . $option[0] . '">
                                                                        </div>
                                                        </div>

                                                        <div class="form-group row">
                                                                <label for="staticEmail" class="col-sm-2 col-form-label">	<input type="radio" readonly>	</label>
                                                                        <div class="col-sm-10">
                                                                                <input class="form-control" type="text" name="form[' . $i . '][1][1]" class="answer" required placeholder="Answer 2..." value="' . $input[1] . '">
                                                                        </div>
                                                        </div>

                                                        <div class="form-group row">
                                                                <label for="staticEmail" class="col-sm-2 col-form-label">	<input type="radio" readonly>	</label>
                                                                        <div class="col-sm-10">
                                                                                <input class="form-control" type="text" name="form[' . $i . '][1][3]" class="answer" required placeholder="Answer 3..." value="' . $input[2] . '">
                                                                        </div>
                                                        </div>
                                        </div>';
                                        }				
                                    $i++;
                                }
                                echo '</div>';
                                ?>
                                <div class="Inputs" id="Inputs">
                                    <div id="place" style="display: none;"></div>
                                </div>
                                <span id="add">+</span>
                                <br>
                                <button style=" background-color: #0084bd;" type="submit" name="submit" class="btn btn-primary btn-lg">Update</button>
                                <!-- <input type="submit" name="submit" class="button" value="Update"> -->
                                <script type="text/javascript">
                                    var button = document.getElementById('add'),
                                            i = <?php echo $i; ?>;

                                    button.onclick = function () {
                                        var place = document.getElementById('place'),
                                                all = document.getElementById('Inputs'),
                                                div = document.createElement('div'),
                                                input = '\
                                                                                <input type="text" name="form[' + i + '][0]" id="' + i + '" placeholder="Write a question...(empty to delete)" required class="text">\
                                                                                <label>Write the answers:</label>\
                                                                                <div class="choises">\
                                                                                        <div>\
                                                                                                <input type="radio" readonly>\
                                                                                                <input type="text" name="form[' + i + '][1][0]" class="answer" required placeholder="Answer 1...">\
                                                                                        </div>\
                                                                                        <div>\
                                                                                                <input type="radio" readonly>\
                                                                                                <input type="text" name="form[' + i + '][1][1]" class="answer" required placeholder="Answer 2...">\
                                                                                        </div>\
                                                                                        <div>\
                                                                                                <input type="radio" readonly>\
                                                                                                <input type="text" name="form[' + i + '][1][3]" class="answer" required placeholder="Answer 3...">\
                                                                                        </div>\
                                                                                </div>\
                                                                        ';
                                        div.className = 'Q';
                                        div.innerHTML = input;
                                        place.parentNode.replaceChild(div, place);
                                        all.innerHTML = all.innerHTML + '<div id="place" style="display: none;"></div>'
                                        i += 1
                                    }
                                </script>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        </body>
        </html>
        <?php
    } else {
        ?>
        <!DOCTYPE html>
        <html>
            <head>
                <title>Surveys list</title>
                <meta charset="utf-8">
                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
                <!-- <link rel="stylesheet" type="text/css" href="css/style2.css">
                <link rel="stylesheet" type="text/css" href="css/style.css"> -->
                <style type="text/css">
                    .clear
                    {
                        clear:both;
                    }
                </style> 
            </head>
            <body>
                <!-- navbar * -->
                <?php include 'include/header.php'; ?>
                <!-- navbar / -->
                <div class="container">


                    <div class="row">
                        <div class="col-sm-8 mt-3 ">
                            <div class="float-right">
                                <a href="add.php" style="color:white;    background-color: #0084bd;" type="button" class="btn btn-primary">Create new survey +</a>
                            </div>
                            <div class="clear"></div>
                            <ul class="list-group list-group-flush">

                                <?php
                                $all = $bdd->query('SELECT * FROM survey ORDER BY ID DESC');
                                while ($get = $all->fetch()) {
                                    echo '
				<li class="list-group-item">
                                    <a href="surveys.php?id=' . $get['ID'] . '">Edit</a>
                                    ' . $get['Surveyname'] . ' <br>
                                     The number of alumni who filled out the survey=
                                     </li>';
                                }
                                ?>
                            </ul>	
                        </div>
                    </div>

                </div>
                <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
                <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
            </body>
        </html>
        <?php
    }
    ?>
    <?php
} else {
    header('location: login.php');
}
?>