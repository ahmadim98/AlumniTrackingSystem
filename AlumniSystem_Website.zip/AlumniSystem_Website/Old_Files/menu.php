<div class="menu">
	<h2><a href="surveys.php">Surveys</a></h2>
	<h2><a href="statistic2.php">Statistics</a></h2>
	<h2><a href="mailbox.php">Mailbox</a></h2>
	<h2><a href="profil.php">Profil</a></h2>
	<h2><a href="chat.php">Chat</a></h2><br>
</div>