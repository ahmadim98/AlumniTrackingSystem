<?php
session_start();
include('database.php');
if (isset($_SESSION['username'])) {
	if (isset($_GET['id'])) {
            
                $GraduateID = $bdd->query('SELECT GraduateID FROM feedback WHERE ID = '.(int) $_GET['id'].'')->fetch()['GraduateID'];
                
                $AlumniName = $bdd->query('SELECT * FROM `alumni` WHERE `alumni_id` = '.$GraduateID.'')->fetch()['name'];
                
                $AdminID = $bdd->query('SELECT ID FROM admin WHERE Username = "'.$_SESSION['username'].'"')->fetch()['ID'];
                
                //send feedback here
		if (isset($_POST['submit'],$_POST['msg']) and mb_strlen(trim($_POST['msg'])) > 0) {
                        $bdd->exec('INSERT INTO `feedbackchat` (`ID`, `feedbackID`, `message`, `sender`, `receiver`) VALUES (NULL, '.$_GET['id'].', "'.htmlspecialchars($_POST['msg']).'", "'.$AdminID.'", "'.$GraduateID.'")');
			header('location: chat.php?id=' . $_GET['id']);
		}
		?>
			<!DOCTYPE html>
			<html>
			<head>
				<title>Chat - <?php echo $AlumniName; ?></title>
				<meta charset="utf-8">
				<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
				<style>
					.messagesX{
						/* width:50%; */
						/* background:red; */
						height:50vh;
						overflow:auto;
						overflow-wrap: break-word;
						
					}
					.aMe{
						width: 90%;
						margin-right: 0;
                                                margin-left: auto;
					}
					.aMe p {
						background: #dcf8c6;
						padding: 5px;
						border-radius: 30px;
						border-bottom-right-radius: 0;
						border-top-right-radius: 5px;
						padding-right: 15px;
					}
					.bHim{
						width: 90%;
						margin-right: auto;
    					margin-left: 0;
					}
					.bHim p {
						background: #e1f0ff;
						padding: 5px;
						border-radius: 30px;
						border-bottom-left-radius: 0;
						border-top-left-radius: 5px;
						padding-left: 15px;
					}
				</style>
			</head>
			<body>
				
					<!-- navbar * -->
					<?php include 'include/header.php'; ?>
					<!-- navbar / -->
					<div class="container"> <!-- * container -->
						<div class="row">  <!-- * row -->
							<div class="col-sm-4 mt-2">				
								<ul class="list-group">
									<li class="list-group-item active" style="    background-color: #0084bd;"><h3>Surveys list</h3></li>
									<li class="list-group-item"><a href="surveys.php">Surveys</a></li>
									<li class="list-group-item"><a href="statistic2.php">Statistics</a></li>
									<li class="list-group-item"><a href="mailbox.php">Mailbox</a></li>
									<li class="list-group-item"><a href="profil.php">Profil</a></li>
									<li class="list-group-item"><a href="chat.php">Chat</a></li>
								</ul>
							</div>
							
							<div class="col-sm-8 mt-3">
								<h4>Chat with <?php echo $AlumniName ?></h4>
								<hr>
								<div class="messagesX">  <!-- * messagesX -->
                                                        <?php
                                                                $feedbackchat = $bdd->query('SELECT * FROM feedbackchat')->fetchAll();
                                                                
                                                                if(!empty($feedbackchat)){
                                                                    foreach($feedbackchat as $chat){
                                                                    $sender = $chat['sender'];
                                                                    //over here we want to check if the sender's id start with 4 means that
                                                                    //the alumni is sending message
                                                                    if($sender[0] == 4){
                                                                        echo '
                                                                            <div class="bHim">
                                                                                    <p>' . $chat['message'] . '</p>
                                                                            </div>
                                                                        ';
                                                                    }else{
                                                                        echo '
                                                                                                <div class="aMe">
                                                                                                        <p class="text-right">' . $chat['message'] . '</p>
                                                                                                </div>
                                                                        ';
                                                                    }
                                                                    
                                                                }
                                                                }else{
                                                                   echo '
                                                                                <br><br><br><br><br><br>
                                                                                        <h1 style="text-align:center;">No message</h1>
                                                                                <br><br><br>
                                                                                '; 
                                                                }
                                                        ?>
								</div> 
							
							<script type="text/javascript">
								var m = document.querySelector('.messagesX');
								window.onload = function () {
									m.scrollTo(0,m.offsetHeight);
								}
							</script>
							<form class="mt-4" method="post" action="">
								<div class="form-group">
									<input style="width: 90%;" type="text" name="msg" class="text" class="form-control" autofocus required autocomplete="false">
									<button style="background-color: #0084bd;" type="submit" name="submit" class="btn btn-primary">Send</button>
								</div>
							</form>
							</div>
							</div>
						</div>  <!-- / row -->
					</div>  <!-- / container -->
				
				<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
				<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
				<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
			</body>
			</html>
		<?php
	}else{
		?>
						<!DOCTYPE html>
			<html>
			<head>
				<title>Chat - <?php echo $FullName; ?></title>
				<meta charset="utf-8">
				<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

				<!-- navbar * -->
					<?php include 'include/header.php'; ?>
					<!-- navbar / -->
					<div class="container"> <!-- * container -->
						<div class="row">  <!-- * row -->
							<div class="col-sm-4 mt-2">				
								<ul class="list-group">
									<li class="list-group-item active" style="    background-color: #0084bd;"><h3>Surveys list</h3></li>
									<li class="list-group-item"><a href="surveys.php">Surveys</a></li>
									<li class="list-group-item"><a href="statistic2.php">Statistics</a></li>
									<li class="list-group-item"><a href="mailbox.php">Mailbox</a></li>
									<li class="list-group-item"><a href="profil.php">Profil</a></li>
									<li class="list-group-item"><a href="chat.php">Chat</a></li>
								</ul>
							</div>

							<div class="col-sm-8 mt-3">
								<h4>Chat with a user</h4>
								<hr>
									<ul class="list-group list-group-flush">
										<?php
                                                                                        //FeedbackID = $bdd->query('SELECT * FROM survey WHERE ID = '.(int) $_GET['id'].'')->fetch()['Surveyname'];
                                                                                        $Feedbacks = $bdd->query('SELECT * FROM feedback')->fetchAll();
                                                                                        
											//$all = $bdd->query('SELECT * FROM users ORDER BY id DESC');
                                                                                        foreach($Feedbacks as $feedback){
                                                                                            echo '
                                                                                                <li class="list-group-item">
                                                                                                        <a href="chat.php?id=' . $feedback['ID'] . '">
                                                                                                                ' . $feedback['title'] . '
                                                                                                        </a>
                                                                                                </li>
														
											    ';
                                                                                        }
										?>
									</ul>
							</div>
						</div>  <!-- / row -->
					</div>  <!-- / container -->

				<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
				<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
				<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
			</body>
			</html>
		<?php
	}
}else{
	header('location: login.php');
}

?>