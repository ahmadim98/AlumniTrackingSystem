<?php
session_start();
include('database.php');

if (isset($_SESSION['username'])) {
	if (isset($_POST['submit'],$_POST['form'],$_POST['Surveyname'])) {
                $AdminID = $bdd->query('SELECT ID FROM admin WHERE Username = "'.$_SESSION['username'].'"')->fetch()['ID'];
		$Surveyname = htmlspecialchars($_POST['Surveyname']);
                $bdd->exec('INSERT INTO `survey`(`ID`, `AdminID`, `Surveyname`) VALUES (NULL,'.$AdminID.',"'.$Surveyname.'")');
                $SurveyID = $bdd->query('SELECT ID FROM survey WHERE Surveyname = "'.$Surveyname.'"')->fetch()['ID'];
                
		foreach ($_POST['form'] as $Question) {
			if (!empty($Question[0])) {
                                $bdd->exec('INSERT INTO `survey_questions`(`ID`, `SurveyID`, `Question`) VALUES (NULL,'.$SurveyID.',"'.$Question[0].'")');
                                
                                $QuestionID = $bdd->query('SELECT ID FROM survey_questions WHERE Question = "'.$Question[0].'" AND SurveyID = '.$SurveyID.'')->fetch()['ID'];
                                
				foreach ($Q[1] as $Option) {//here as 
                                    $bdd->exec('INSERT INTO `survey_options`(`QuestionID`, `SurveyID`, `Optionname`) VALUES ('.$QuestionID.','.$SurveyID.',"'.$Option.'")');
				}
			}
                    
		}
		header('location: surveys.php?id=' . $id);
	}
	?>
		<!DOCTYPE html>
			<html>
			<head>
				<title>Surveys list</title>
				<meta charset="utf-8">
				<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
				<!-- <link rel="stylesheet" type="text/css" href="css/style2.css">
				<link rel="stylesheet" type="text/css" href="css/style.css"> -->
				</head>
				<body>
				<!-- navbar * -->
				<?php include 'include/header.php'; ?>
				<!-- navbar / -->

				<div class="container">
					<div class="row">
						<div class="col-sm-8 mt-3 text-center">
							<h4>Create new survey</h4>
							<hr>
							<form method="post" action="">
								<div class="form-group">
									<input type="text" name="Surveyname" class="form-control"  placeholder="Write a title of this survey..." required class="text">
								</div>
								<div class="Inputs" id="Inputs">
									<div class="form-group">
										<input type="text"  name="form[0][0]" class="form-control" id="0" placeholder="Write a question..." required class="text">
									</div>
										<label>Write the answers:</label>
										<div class="choises">
											<div class="form-group row">
												<label for="staticEmail" class="col-sm-2 col-form-label">	<input type="radio" readonly>	</label>
													<div class="col-sm-10">
														<input class="form-control" type="text" name="form[0][1][0]" class="answer" required placeholder="Answer 1...">
													</div>
											</div>
											<div class="form-group row">
												<label for="staticEmail" class="col-sm-2 col-form-label">	<input type="radio" readonly>	</label>
												<div class="col-sm-10">
													<input  class="form-control"  type="text" name="form[0][1][1]" class="answer" required placeholder="Answer 2...">
												</div>
											</div>
											<div class="form-group row">
												<label for="staticEmail" class="col-sm-2 col-form-label">	<input type="radio" readonly>	</label>
													<div class="col-sm-10">
													<input class="form-control" type="text" name="form[0][1][3]" class="answer" required placeholder="Answer 3...">
												</div>
											</div>
										</div>
									<div id="place" style="display: none;"></div>
								</div>
								<span id="add">+</span>
								<br>
								<button type="submit" name="submit" class="btn btn-success btn-lg">Create +</button>
							</form>
						</div>
					</div>
				</div>
					<script type="text/javascript">
						var button = document.getElementById('add'),
							i = 1;

						button.onclick = function () {
							var place = document.getElementById('place'),
								all = document.getElementById('Inputs'),
								div = document.createElement('div'),
								input = '\
									<input type="text" name="form['+i+'][0]" id="'+i+'" placeholder="Write a question..." required class="text">\
									<label>Write the answers:</label>\
									<div class="choises">\
                                                                            <div>\
                                                                                <input type="radio" readonly>\
                                                                                <input type="text" name="form['+i+'][1][0]" class="answer" required placeholder="Answer 1...">\
                                                                                    </div>\
                                                                                        <div>\
                                                                                            <input type="radio" readonly>\
                                                                                            <input type="text" name="form['+i+'][1][1]" class="answer" required placeholder="Answer 2...">\
                                                                                        </div>\
                                                                                        <div>\
                                                                                            <input type="radio" readonly>\
                                                                                            <input type="text" name="form['+i+'][1][3]" class="answer" required placeholder="Answer 3...">\
                                                                                        </div>\
                                                                                    </div>\
										';
							div.className = 'Q';
							div.innerHTML = input;
							place.parentNode.replaceChild(div, place);
							all.innerHTML = all.innerHTML + '<div id="place" style="display: none;"></div>'
							i+=1
						}
					</script>
				</div>
			</div>
			<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
			<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
		</body>
		</html>
	<?php
}else{
	header('location: login.php');
}
?>