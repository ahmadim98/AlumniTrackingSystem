-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2020 at 12:45 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alumniapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `ID` int(9) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Major` varchar(30) DEFAULT NULL,
  `TwitterAccount` varchar(100) NOT NULL,
  `Phone` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`ID`, `Name`, `Major`, `TwitterAccount`, `Phone`) VALUES
(437101237, '', NULL, '', 0);

INSERT INTO `alumni` (`ID`, `Name`, `Major` , `TwitterAccount`, `Phone`) VALUES
(1, 'manager', 'SWE', '', 0);
INSERT INTO `alumni` (`ID`, `Name`, `Major` , `TwitterAccount`, `Phone`) VALUES
(2, 'ff', 'SWE', '', 0);
INSERT INTO `alumni` (`ID`, `Name`, `Major` , `TwitterAccount`, `Phone`) VALUES
(3, 'qq', 'SWE', '', 0);
INSERT INTO `alumni` (`ID`, `Name`, `Major` , `TwitterAccount`, `Phone`) VALUES
(4, 'ww', 'CSC', '', 0);
INSERT INTO `alumni` (`ID`, `Name`, `Major` , `TwitterAccount`, `Phone`) VALUES
(5, 'ee', 'CSC', '', 0);
INSERT INTO `alumni` (`ID`, `Name`, `Major` , `TwitterAccount`, `Phone`) VALUES
(6, 'rr', 'CE', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `ID` int(11) NOT NULL,
  `GraduateID` int(11) NOT NULL,
  `title` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`ID`, `GraduateID`, `title`) VALUES
(0, 437101237, '03082020');

-- --------------------------------------------------------

--
-- Table structure for table `feedbackchat`
--

CREATE TABLE `feedbackchat` (
  `ID` int(11) NOT NULL,
  `feedbackID` int(11) NOT NULL,
  `message` text NOT NULL,
  `message_source` varchar(30) NOT NULL,
  `message_destination` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbackchat`
--

INSERT INTO `feedbackchat` (`ID`, `feedbackID`, `message`, `message_source`, `message_destination`) VALUES
(1, 0, 'test message hhhhhhhhhhhhh', '437101237', '1'),
(2, 0, 'gdagdfafdasfdsa', '1', '437101237'),
(3, 0, 'fdasfdsa', '1', '437101237'),
(4, 0, 'this is small test :D', '437101237', '1'),
(5, 0, 'this is other test', '437101237', '1'),
(6, 0, 'hjhjkj', '437101237', '1');

-- --------------------------------------------------------

--
-- Table structure for table `survey`
--

CREATE TABLE `survey` (
  `ID` int(11) NOT NULL,
  `adminID` int(11) NOT NULL,
  `Surveyname` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey`
--

INSERT INTO `survey` (`ID`, `adminID`, `Surveyname`) VALUES
(1, 1, 'test survey'),
(2, 1, 'second survey');

-- --------------------------------------------------------

--
-- Table structure for table `survey_answers`
--

CREATE TABLE `survey_answers` (
  `SurveyID` int(11) NOT NULL,
  `QuestionID` int(11) NOT NULL,
  `GraduateID` int(11) NOT NULL,
  `ChoosenOption` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_answers`
--

INSERT INTO `survey_answers` (`SurveyID`, `QuestionID`, `GraduateID`, `ChoosenOption`) VALUES
(2, 2, 437101237, 'maid'),
(2, 1, 437101237, 'yes'),
(2, 4, 437101237, 'far'),
(2, 3, 437101237, 'yes'),
(2, 5, 437101237, 'no'),
(1, 1, 437101237, 'yes'),
(1, 2, 437101237, 'office'),
(1, 3, 437101237, 'choclate'),
(1, 4, 437101237, 'alot'),
(1, 5, 437101237, 'good');

-- --------------------------------------------------------

--
-- Table structure for table `survey_options`
--

CREATE TABLE `survey_options` (
  `QuestionID` int(11) NOT NULL,
  `SurveyID` int(11) NOT NULL,
  `OptionName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_options`
--

INSERT INTO `survey_options` (`QuestionID`, `SurveyID`, `OptionName`) VALUES
(1, 1, 'yes'),
(1, 1, 'no'),
(1, 1, 'still looking for job'),
(2, 1, 'office'),
(2, 1, 'on site'),
(2, 1, 'remote'),
(3, 1, 'choclate'),
(3, 1, 'vanila'),
(3, 1, 'other'),
(4, 1, 'half and half'),
(4, 1, 'alot'),
(4, 1, 'very little'),
(5, 1, 'good'),
(5, 1, 'bad'),
(5, 1, 'medium'),
(6, 2, 'yes'),
(6, 2, 'my family'),
(6, 2, 'i have special cheif'),
(7, 2, 'maid'),
(7, 2, 'yes'),
(7, 2, 'family'),
(8, 2, ' no'),
(8, 2, 'yes'),
(8, 2, 'still looking ;)'),
(9, 2, 'far'),
(9, 2, 'soon'),
(9, 2, 'idk'),
(10, 2, 'no'),
(10, 2, 'yes'),
(10, 2, 'i dont want');

-- --------------------------------------------------------

--
-- Table structure for table `survey_questions`
--

CREATE TABLE `survey_questions` (
  `ID` int(11) NOT NULL,
  `SurveyID` int(11) NOT NULL,
  `question` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_questions`
--

INSERT INTO `survey_questions` (`ID`, `SurveyID`, `question`) VALUES
(1, 1, 'r u employed'),
(2, 1, 'which job u prefer'),
(3, 1, 'what type of ice u like'),
(4, 1, 'do u drink water'),
(5, 1, 'what do u think about the app'),
(6, 2, 'do u cock'),
(7, 2, 'do u clean ur room'),
(8, 2, 'do u have gf'),
(9, 2, 'when will u get married'),
(10, 2, 'r u single ?');

--
-- Indexes for dumped tables
--
--
-- Table structure for table `experience`
--
DROP TABLE IF EXISTS `experience`;
CREATE TABLE IF NOT EXISTS `experience` (
    `job_id` int(11) NOT NULL,
    `jobtitle` varchar(255) NOT NULL,
  `ID` int(11) NOT NULL,
    `place` varchar(255) NOT NULL,
    `startD` year NOT NULL,
    `endD` year NOT NULL,
    PRIMARY KEY (`job_id`),
    FOREIGN KEY (ID) REFERENCES alumni(ID)
    
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `experience` (`job_ID`,`jobtitle`, `ID`, `place`, `startD`, `endD`) VALUES
(1,'dev', 1 ,'STC',  2014 , 2015);
INSERT INTO `experience` (`job_ID`,`jobtitle`, `ID`, `place`, `startD`, `endD`) VALUES
(3,'des', 2 ,'mobily',  2012 , 2015);
INSERT INTO `experience` (`job_ID`,`jobtitle`, `ID`, `place`, `startD`, `endD`) VALUES
(5,'anal', 3 ,'TC',  2016 , 2017);
INSERT INTO `experience` (`job_ID`,`jobtitle`, `ID`, `place`, `startD`, `endD`) VALUES
(7,'anal', 4 ,'gov',  2013 , 2015);
INSERT INTO `experience` (`job_ID`,`jobtitle`, `ID`, `place`, `startD`, `endD`) VALUES
(8,'dev', 5 ,'STC',  2015 , 2016);
INSERT INTO `experience` (`job_ID`,`jobtitle`, `ID`, `place`, `startD`, `endD`) VALUES
(9,'dev', 6 ,'STC',  2014 , 2015);

--
-- Table structure for table `Admin`
--
DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL  ,
    `name` varchar (255) NOT NULL,
    `password` varchar(255) NOT NULL,
    PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `admin` (`admin_id`, `name`, `password`) VALUES
(1, 'mana', '0000');

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `feedbackchat`
--
ALTER TABLE `feedbackchat`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `survey`
--
ALTER TABLE `survey`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedbackchat`
--
ALTER TABLE `feedbackchat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `survey`
--
ALTER TABLE `survey`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `survey_questions`
--
ALTER TABLE `survey_questions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
