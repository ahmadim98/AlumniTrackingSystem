<?php
	session_start();
	include('database.php');

	if (!isset($_SESSION['username'])) {
            if (isset($_POST['submit'], $_POST['username'], $_POST['password'])) {
                $username = $_POST['username'];
                $password = $_POST['password'];
                if (mb_strlen($password) > 5) {
                    $password = sha1($password);
                    $login = $bdd->prepare('SELECT * FROM admin WHERE Username = ?');
                    $login->execute(array($username));
                    if ($login->rowCount() == 1) {
                        if ($password == $login->fetch()['Password']) {
                            $_SESSION['username'] = $username;
                            header('location: statistic2.php');
                        } else {
                            $error = 'The username/password is/are wrong';
                        }
                    } else {
                        $error = 'There is no account with this username';
                    }
                } else {
                    $error = 'There is a problem in the password';
                }
            }
?>
            <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

        <style>
            #mydiv {
        position:fixed;
        top: 50%;
        left: 50%;
        width:30em;

        margin-top: -18em; /*set to a negative number 1/2 of your height*/
        margin-left: -15em; /*set to a negative number 1/2 of your width*/
        border: 1px solid #ccc;
        background-color: #f3f3f3;
    }
        </style>
    </head>
    <body>

        <div class="container">
            <div class="row" >
                <div class="col-sm">
                    <!-- One of three columns -->
                </div>
                <div class="col-sm" id="mydiv" style="background:#0084bd">
                <div class="form-group text-center ">
                <img src="https://is1-ssl.mzstatic.com/image/thumb/Purple113/v4/b5/4a/d8/b54ad8de-fd80-1fc4-0734-8dbd6d4447af/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/320x0w.png" class="img-fluid" alt="Responsive image">
                </div>
                <?php
                        if (isset($error)) {
                            echo '
                            <div class="alert alert-danger text-center" role="alert">
                                ' . $error . '
                            </div>';

                        }
                    ?>
                    <form method="POST">
                        <div class="form-group">
                            <input type="text" name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Username">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" required class="form-control" id="exampleInputPassword1" placeholder="Password">
                        </div>
                        <button name="submit" type="submit" class="btn btn-primary btn-lg btn-block mb-3" style="background-color: #0084bd;border-color: #ffffff;">Login</button>
                    </form>
                </div>
                <div class="col-sm">
                    <!-- One of three columns -->
                </div>
            </div>
        </div>





    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    </body>
</html>

		<?php
	}else{
		header('location: index.php');
	}
?>